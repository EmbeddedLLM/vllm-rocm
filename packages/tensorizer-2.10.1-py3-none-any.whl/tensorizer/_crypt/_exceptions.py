class CryptographyError(Exception):
    pass
